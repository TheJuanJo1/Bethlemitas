


<?php $__env->startSection('first_frame'); ?>
    <div class="p-4 bg-white rounded-lg shadow-md">
        <h2 class="mb-4 text-xl font-semibold">Crear grupo</h2>
        <form action="<?php echo e(route('store.group')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="grupo" class="block text-sm font-medium text-gray-700">Grupo *</label>
                <input type="text" id="grupo" name="group"
                    class="block w-full px-3 py-2 mt-1 bg-gray-100 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    maxlength="50" value="<?php echo e(old('group')); ?>">
                <?php $__errorArgs = ['group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500">
                        <span class="font-medium">Grupo ya existente o el campo se encuentra vacío.</span>
                    </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="px-4 py-2 text-white bg-blue-500 rounded-md hover:bg-blue-600">
                Guardar
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('list_table'); ?>
    <div class="p-4 overflow-x-auto bg-white rounded-lg shadow-md">
        <h2 class="mb-4 text-xl font-semibold">Lista de grupos</h2>
        <div class="flex mb-4">
            <form class="flex mb-4" action="<?php echo e(route('create.group')); ?>">
                <input type="search" name="search" placeholder="Buscar..."
                    class="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-md">
                <button type="submit" class="px-3 py-2 ml-2 text-gray-600 bg-gray-300 rounded-md">
                    🔍
                </button>
            </form>
        </div>
        <div style="max-height: 530px; overflow-y: auto;">
            <table class="w-full table-auto">
                <thead class="bg-gray-200">
                    <tr class="text-left">
                        <th class="px-4 py-2">Grupo</th>
                        <th class="px-4 py-2">Docentes asignados al grupo</th>
                        <th class="px-4 py-2">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-4 py-2 border"><?php echo e($group->group); ?></td>
                            <td class="px-4 py-2 border">
                                <?php $__empty_1 = true; $__currentLoopData = $group->teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php echo e($teacher->name); ?> <?php echo e($teacher->last_name); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <span class="text-gray-500">Sin docentes asignados</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-2 border">
                                <button type="button" class="text-blue-600 hover:text-blue-800 hover:underline edit_group"
                                    data-id="<?php echo e($group->id); ?>" name-group="<?php echo e($group->group); ?>">
                                    Editar
                                </button>
                                <form action="<?php echo e(route('destroy.group', $group->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:underline"
                                        onclick="return confirm('¿Estás seguro de eliminar este grupo?')">
                                        Eliminar
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('second_frame'); ?>
    <div class="hidden p-4 bg-white rounded-lg shadow-md" id="modal_edit_group">
        <h2 class="mb-4 text-xl font-semibold">Editar grupo</h2>
        <form action="<?php echo e(route('update.group')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" id="groupId" name="groupId" value="">
            <div class="mb-4">
                <label for="grupo_edit" class="block text-sm font-medium text-gray-700">Grupo *</label>
                <input type="text" id="grupo_edit" name="grupo_edit"
                    class="block w-full px-3 py-2 mt-1 bg-gray-100 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                <?php $__errorArgs = ['grupo_edit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Grupo ya existente o el
                            campo se ecuentra vacío.</span></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="px-4 py-2 text-white bg-blue-500 rounded-md hover:bg-blue-600">Editar</button>
            <button type="button"
                class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-600 button_exit">Cancelar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.base_structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PiarManager\resources\views/academic/createGroup.blade.php ENDPATH**/ ?>