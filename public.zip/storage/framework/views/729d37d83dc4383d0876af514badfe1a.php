

<?php $__env->startSection('title', 'Creation'); ?>

<?php $__env->startSection('content'); ?>
<div class="container p-4 mx-auto">
    <div class="grid grid-cols-3 gap-4">
        <!-- Primera columna -->
        <div class="flex flex-col col-span-1 gap-4">
            <!-- Panel de creación de grupos (primera fila) -->
            <div>
                <?php echo $__env->yieldContent('first_frame'); ?>
            </div>
            <!-- Panel de edición de grupos (segunda fila) -->
            <div>
                <?php echo $__env->yieldContent('second_frame'); ?>
            </div>
        </div>

        <!-- Segunda columna (tabla de grupos) -->
        <div class="col-span-2">
            <?php echo $__env->yieldContent('list_table'); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
    <script src="<?php echo e(asset('scripts/group.js')); ?>"></script>
    <script src="<?php echo e(asset('scripts/degree.js')); ?>"></script>
    <script src="<?php echo e(asset('scripts/area.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PiarManager\resources\views/layout/base_structure.blade.php ENDPATH**/ ?>