<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <div class="flex flex-col items-center justify-center w-full h-screen px-6 py-12 bg-center bg-cover lg:px-8" style="background-image: url('<?php echo e(asset('img/colegio1.jpg')); ?>');">
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
        <?php echo $__env->yieldContent('contentLogin'); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\User\Downloads\PiarManager -P\resources\views/layoutLogin.blade.php ENDPATH**/ ?>