
    
<?php $__env->startSection('title', 'Lista de Usuarios'); ?>

<?php $__env->startSection('content'); ?>



<div class="p-4">
    <!-- Encabezado de la tabla -->
    <div class="sticky top-0 flex flex-col mb-4 lg:flex-row lg:items-center lg:justify-between">
        <h2 class="text-xl font-semibold">Lista de usuarios</h2>
        <div class="relative">
            <form action="<?php echo e(route('index.users')); ?>">
                <input type="search" name="search" class="py-2 pl-4 pr-8 border rounded-lg shadow-sm" placeholder="Buscar...">
                <button type="submit"
                    class="px-4 py-2 font-bold rounded-r bg-purple-white hover:bg-purple-200 text-purple-lighter">
                    <svg version="1.1" class="h-4 text-dark" xmlns="http://www.w3.org/2000/svg"
                        xmlns:xlink= "http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 52.966 52.966"
                        style="enable-background:new 0 0 52.966 52.966;" xml:space="preserve">
                        <path d="M51.704,51.273L36.845,35.82c3.79-3.801,6.138-9.041,6.138-14.82c0-11.58-9.42-21-21-21s-21,9.42-21,21s9.42,21,21,21
                                    c5.083,0,9.748-1.817,13.384-4.832l14.895,15.491c0.196,0.205,0.458,0.307,0.721,0.307c0.25,0,0.499-0.093,0.693-0.279
                                    C52.074,52.304,52.086,51.671,51.704,51.273z M21.983,40c-10.477,0-19-8.523-19-19s8.523-19,19-19s19,8.523,19,19
                                    S32.459,40,21.983,40z" />
                    </svg>
                </button>
            </form>
        </div>
    </div>

    <!-- Tabla de usuarios -->
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white rounded-lg shadow-md">
            <thead class="bg-gray-200">
                <tr>
                    <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-700 uppercase">Nombre completo</th>
                    <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-700 uppercase">Número de documento</th>
                    <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-700 uppercase">Areas</th>
                    <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-700 uppercase">Grupos a cargo</th>
                    <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-700 uppercase">Director de grupo</th>
                    <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-700 uppercase">Role</th>
                    <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-700 uppercase">Acciones</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>  
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($user->number_documment); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if($user->areas->isNotEmpty()): ?>
                                <?php echo e($user->areas->pluck('name_area')->implode(', ')); ?> <!-- Muestra los nombres de los grupos separados por comas -->
                            <?php else: ?>
                                "Sin Areas"
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if($user->groups->isNotEmpty()): ?>
                                <?php echo e($user->groups->pluck('group')->implode(', ')); ?> <!-- Muestra los nombres de los grupos separados por comas -->
                            <?php else: ?>
                                "Sin Grupos"
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap"> <?php echo e($user->director ? $user->director->group : '"Sin Grupo"'); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if(is_array($userRoles[$user->id])): ?>
                            <span class="badge badge-primary"><?php echo e(implode(', ', $userRoles[$user->id])); ?></span>
                            <?php else: ?>
                            <?php echo e($userRoles[$user->id]); ?>

                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <a href="<?php echo e(route('edit.user', $user->id)); ?>" class="text-blue-500 hover:underline">Editar</a>
                            <span class="mx-2">|</span>
                            <form action="<?php echo e(route('destroy.user', $user->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button type="submit" class="text-red-500 hover:underline" onclick="return confirm('¿Estás seguro de eliminar este usuario?')">
                                    Eliminar
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($users->links()); ?> <!-- Para la paginación -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Downloads\PiarManager -P\resources\views/academic/userList.blade.php ENDPATH**/ ?>