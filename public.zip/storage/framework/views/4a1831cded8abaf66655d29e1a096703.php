<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="#">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Historial'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="p-2 text-3xl font-bold text-gray-700"><?php echo e($student->name); ?> <?php echo e($student->last_name); ?></h1>
    <br>
    
    <div class="flex justify-center p-[2px]">
        <div class="w-[100%] px-4 bg-white rounded-lg shadow-md h-[45rem] overflow-auto">
            <div class="p-4 border-b bg-[white] z-10 sticky top-0 shadow-md w-full ">
                <h1 class="text-3xl font-bold text-gray-700">Remisiones</h1>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse table-auto">
                    <thead>
                        <tr class="text-sm text-gray-600 uppercase bg-gray-200">
                            <th class="px-4 py-2 border">Fecha de remisión</th>
                            <th class="px-4 py-2 border">Nombre de quién remite</th>
                            <th class="px-4 py-2 border">Última edición</th>
                            <th class="px-4 py-2 border">Detalles</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700">
                        <?php $__empty_1 = true; $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-100">
                                    <td class="px-4 py-2 text-center border"><?php echo e($referral->created_at->format('Y-m-d')); ?></td>
                                    <td class="px-4 py-2 text-center border"><?php echo e($referral->user_teacher->name); ?> <?php echo e($referral->user_teacher->last_name); ?></td>
                                    <td class="px-4 py-2 text-center border"><?php echo e($referral->updated_at->format('Y-m-d')); ?></td>
                                    <td class="px-4 py-2 text-center border">
                                        <a href="<?php echo e(route('history.details.referral', $referral->id)); ?>" class="text-blue-500 hover:underline">Ver +</a>
                                    </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="px-4 py-2 text-center border">No se encontraron registros</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo e($referrals->links()); ?> <!-- Para la paginación -->

    <br>

    
    <div class="flex justify-center p-[2px]">
        <div class="w-[100%] px-4 bg-white rounded-lg shadow-md h-[45rem] overflow-auto">
            <div class="p-4 border-b bg-[white] z-10 sticky top-0 shadow-md w-full ">
                <h1 class="text-3xl font-bold text-gray-700">Informes</h1>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse table-auto">
                    <thead>
                        <tr class="text-sm text-gray-600 uppercase bg-gray-200">
                            <th class="px-4 py-2 border">Fecha de informe</th>
                            <th class="px-4 py-2 border">Título</th>
                            <th class="px-4 py-2 border">Nombre de quién redacta el informe</th>
                            <th class="px-4 py-2 border">Última edición</th>
                            <th class="px-4 py-2 border">Detalles</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700">
                        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-100">
                                <td class="px-4 py-2 text-center border"><?php echo e(optional($report->created_at)->format('Y-m-d')); ?></td>
                                <td class="px-4 py-2 text-center border"><?php echo e($report->title_report); ?></td>
                                <td class="px-4 py-2 text-center border">
                                    <?php echo e($report->user_psychology->name ?? ''); ?> <?php echo e($report->user_psychology->last_name ?? ''); ?>

                                </td>
                                <td class="px-4 py-2 text-center border"><?php echo e(optional($report->updated_at)->format('Y-m-d')); ?></td>
                                <td class="px-4 py-2 text-center border">
                                    <a href="<?php echo e(route('history.details.report', $report->id)); ?>" class="text-blue-500 hover:underline">Ver +</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="px-4 py-2 text-center border">No se encontraron registros</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo e($reports->links()); ?> <!-- Para la paginación -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PiarManager\resources\views/psycho/studentHistory.blade.php ENDPATH**/ ?>