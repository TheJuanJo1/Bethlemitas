

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/createUser.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Crear Usuario'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 style="font-size: 32px; text-align: left; margin-bottom: 40px; font-weight: 600;">Crear usuario</h2>
        <form action="<?php echo e(route('store.user')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="container-div">
                <div class="form-group">
                    <div class="form-group-half">
                        <label for="groups">Role *</label>
                        <select id="role" name="role" required>
                            <option value="">Seleccionar</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"> <?php echo e($role->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="form-group-half">
                        <label for="number_documment">Número de documento *</label>
                        <input type="text" id="number_documment" name="number_documment" value="<?php echo e(old('number_documment')); ?>" placeholder="Número de documento" required>
                        <?php $__errorArgs = ['number_documment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">El número de documento ya se encuentra registrado o no tiene la longitud requerida (max 11)</span></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="form-group-half">
                        <label for="name">Nombre/s *</label>
                        <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="form-group-half">
                        <label for="lastname">Apellido/s *</label>
                        <input type="text" id="last_name" name="last_name" value="<?php echo e(old('last_name')); ?>" placeholder="Apellido" required>
                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">Incorrecto</span></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group-half">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">El email ya se encuentra registrado</span></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-group" >       
                    <div class="form-group-half" id="group_areas">
                        <label for="areas">Areas * (manten presionada la tecla Ctrl y seleciona las areas):</label>
                        <select id="areas" name="areas[]" multiple disabled>
                            <option value="">Seleccionar</option>
                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($area->id); ?>" 
                                <?php echo e(in_array($area->id, array_column($selectedAreas ?? [], 'id')) ? 'selected' : ''); ?>>
                                <?php echo e($area->name_area); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['areas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">¡Error! Campo vacío</span></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group-half" id="group_load_group">
                        <label for="groups">Grupos a cargo * (manten presionada la tecla Ctrl y seleciona los grupos):</label>
                        <select id="groups" name="groups[]" multiple disabled>
                            <option value="">Seleccionar</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($group->id); ?>"
                                    <?php echo e(in_array($group->id, old('groups', [])) ? 'selected' : ''); ?>>
                                    <?php echo e($group->group); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['groups'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">¡Error! Campo vacío</span></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group-half" id="group_group_director">
                        <label for="group_director">Director de grupo </label>
                        <select id="group_director" name="group_director" disabled>
                            <option value="">Seleccionar</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($group->id); ?>" <?php echo e(old('group_director') == $group->id ? 'selected' : ''); ?>>
                                    <?php echo e($group->group); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['group_director'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">¡Error! El grupo ya cuenta con un director de grupo.</span></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group-half" id="group_load_degree">
                        <label for="load_degree">Grados a cargo * (manten presionada la tecla Ctrl y seleciona los grados):</label>
                        <select id="load_degree" name="load_degree[]" multiple disabled>
                            <option value="">Seleccionar</option>
                            <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($degree->id); ?>"><?php echo e($degree->degree); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['load_degree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 dark:text-red-500"><span class="font-medium">¡Error! Campo vacío</span></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                </div>

            </div>

            <!-- Contenedor para los diseños generados -->
            <p id='description'></p>
            <div id="selected-areas-container"></div>

            <br>

            <button type="submit" class="btn">Crear usuario</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
    <script>
        // Definir la variable con los datos de la base de datos
        const dbOptions = <?php echo json_encode($groups, 15, 512) ?>;
    </script>
    
    <script src="<?php echo e(asset('scripts/createUser.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Downloads\PiarManager -P\resources\views/academic/createUser.blade.php ENDPATH**/ ?>